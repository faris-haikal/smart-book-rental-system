<?php
// file: soap-client.php
$client = new SoapClient(null, [
    'location' => 'http://localhost/smart-book-rental-system/api/soap-server.php',
    'uri'      => 'http://localhost/smart-book-rental-system/api/soap'
]);

$result = $client->checkBookStatus(1);
echo "Tajuk: {$result['title']}, Status: {$result['status']}";
