-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2025 at 12:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_books`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `status` enum('available','rented') DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `status`) VALUES
(31, 'Pemrograman PHP Asas', 'Ahmad Faisal', 'rented'),
(32, 'Laravel Untuk Pemula', 'Nur Syafiqah', 'rented'),
(33, 'Belajar MySQL Dalam 7 Hari', 'Hassan Zulkifli', 'rented'),
(34, 'JavaScript Interaktif', 'Rina Kamaruddin', 'available'),
(35, 'HTML & CSS untuk Frontend', 'Khai Azmi', 'available'),
(36, 'Asas Python', 'Haziq Farhan', 'rented'),
(37, 'Kuasai Java', 'Fatimah Omar', 'available'),
(38, 'Reka Bentuk UI/UX', 'Siti Aisyah', 'rented'),
(39, 'Data Structure & Algorithms', 'Dr. Amirul', 'rented'),
(40, 'Web Development Lengkap', 'Zul Rahman', 'available'),
(41, 'Projek Sistem Maklumat', 'Fazlina Huda', 'rented'),
(42, 'Pemrograman C++ Terkini', 'Syahmi Nordin', 'available'),
(43, 'Mobile App dengan Flutter', 'Azreen Zainal', 'rented'),
(44, 'Pemikiran Komputasional', 'Dr. Farah Nadiah', 'available'),
(45, 'Blockchain & Web3 Asas', 'Naim Baharuddin', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL,
  `rental_id` int(11) DEFAULT NULL,
  `courier_id` int(11) DEFAULT NULL,
  `delivery_status` enum('pending','delivered','returned') DEFAULT 'pending',
  `delivered_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`id`, `rental_id`, `courier_id`, `delivery_status`, `delivered_at`) VALUES
(20, 22, 46, 'returned', '2025-07-02 03:52:14'),
(21, 23, 46, 'returned', '2025-07-02 03:52:55'),
(22, 24, 46, 'returned', '2025-07-02 03:55:42'),
(23, 25, 46, 'returned', '2025-07-02 03:54:51'),
(24, 26, 46, 'returned', '2025-07-02 04:05:02'),
(25, 27, 46, 'returned', '2025-07-02 04:05:01'),
(26, 28, 46, 'returned', '2025-07-02 04:04:59'),
(27, 29, 46, 'pending', NULL),
(28, 30, 46, 'pending', NULL),
(29, 31, 46, 'delivered', '2025-07-02 04:13:01'),
(30, 32, 46, 'delivered', '2025-07-02 04:13:34'),
(31, 33, 46, 'returned', '2025-07-02 04:13:25'),
(32, 34, 46, 'returned', '2025-07-02 04:11:43'),
(33, 35, 46, 'pending', NULL),
(34, 36, 46, 'pending', NULL),
(35, 37, 48, 'delivered', '2025-07-02 04:39:42'),
(36, 38, 48, 'returned', '2025-07-02 04:39:36'),
(37, 39, 48, 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `rent_date` datetime DEFAULT current_timestamp(),
  `return_date` datetime DEFAULT NULL,
  `status` enum('ongoing','returned') DEFAULT 'ongoing'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`id`, `user_id`, `book_id`, `rent_date`, `return_date`, `status`) VALUES
(22, 1, 31, '2025-07-02 01:19:31', '2025-07-02 03:57:04', 'returned'),
(23, 1, 32, '2025-07-02 01:38:03', '2025-07-02 03:57:05', 'returned'),
(24, 1, 33, '2025-07-02 01:38:21', '2025-07-02 04:05:11', 'returned'),
(25, 1, 37, '2025-07-02 03:54:27', '2025-07-02 04:05:10', 'returned'),
(26, 1, 42, '2025-07-02 03:54:30', '2025-07-02 04:05:08', 'returned'),
(27, 1, 44, '2025-07-02 03:54:33', '2025-07-02 04:05:06', 'returned'),
(28, 1, 35, '2025-07-02 03:54:35', '2025-07-02 04:05:05', 'returned'),
(29, 1, 31, '2025-07-02 04:08:04', NULL, 'ongoing'),
(30, 1, 36, '2025-07-02 04:08:06', NULL, 'ongoing'),
(31, 1, 41, '2025-07-02 04:08:08', NULL, 'ongoing'),
(32, 45, 38, '2025-07-02 04:08:53', NULL, 'ongoing'),
(33, 45, 33, '2025-07-02 04:08:54', '2025-07-02 04:15:06', 'returned'),
(34, 45, 45, '2025-07-02 04:08:56', '2025-07-02 04:13:36', 'returned'),
(35, 1, 32, '2025-07-02 04:29:02', NULL, 'ongoing'),
(36, 1, 39, '2025-07-02 04:29:07', NULL, 'ongoing'),
(37, 1, 43, '2025-07-02 04:29:09', NULL, 'ongoing'),
(38, 1, 35, '2025-07-02 04:29:11', '2025-07-02 04:41:10', 'returned'),
(39, 1, 33, '2025-07-09 18:45:05', NULL, 'ongoing');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('user','courier') DEFAULT 'user',
  `token` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `token`, `address`) VALUES
(1, 'Datu Azrul', 'datuazrul04@gmail.com', '$2y$10$v9E5NtyKouGzYWezwbw9dO11wG7dYA/TGOfIk3YdsvV2qQzOtYqh2', 'user', NULL, 'DGF 10 Blok D Vista Sri Melalin'),
(45, 'Mazlan Bin Amri', 'mazlan606@gmail.com', '$2y$10$ed05hxHTFNVEDOPI0z17Quret8hSrVSCcZQqyQEzPANTsY7HTYbLa', 'user', NULL, NULL),
(46, 'Faris Haikal', 'Haikal12@gmail.com', '$2y$10$38eavRX4TyCAMQM9.ezURuXzRvQr7yPn0LN35RAROclxbQnYk9QLy', 'courier', NULL, 'UTeM, Durian Tunggal, Melaka'),
(48, 'Kmi', 'kamil49@example.com', '$2y$10$/7s.o5/q5UTFj5Q2cil/K.RZkxYQFgj/nKgapM0MZsyLScEXrgeMG', 'courier', NULL, 'UTeM, Durian Tunggal, Melaka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rental_id` (`rental_id`),
  ADD KEY `courier_id` (`courier_id`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `deliveries`
--
ALTER TABLE `deliveries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD CONSTRAINT `deliveries_ibfk_1` FOREIGN KEY (`rental_id`) REFERENCES `rentals` (`id`),
  ADD CONSTRAINT `deliveries_ibfk_2` FOREIGN KEY (`courier_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
