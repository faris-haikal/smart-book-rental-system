<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Status Sewaan Buku</title>
</head>
<body>

  <div id="user-info"></div>

  <div id="buttons">
    <button onclick="goToBooks()">Pergi ke Senarai Buku</button>
    <button onclick="logout()">Log Keluar</button>
  </div>

  <h2>Status Sewaan Buku</h2>
  <div id="status-list">Memuatkan...</div>

  <script>
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user || user.role !== "user") {
      alert("Sila log masuk sebagai pengguna.");
      window.location.href = "login.php";
    }

    document.getElementById("user-info").innerHTML = `<strong>Pengguna:</strong> ${user.name} (${user.email})`;

    function logout() {
      if (confirm("Log keluar sekarang?")) {
        localStorage.removeItem("user");
        window.location.href = "login.php";
      }
    }

    function goToBooks() {
      window.location.href = "books.php";
    }

    async function loadStatus() {
      const res = await fetch("../api/status.php", {
        method: "POST",
        body: JSON.stringify({ user_id: user.id })
      });

      const data = await res.json();

      if (data.length === 0) {
        document.getElementById("status-list").innerHTML = "<em>Tiada sewaan direkodkan.</em>";
        return;
      }

      let html = `
        <table>
          <thead>
            <tr>
              <th>Bil</th>
              <th>Tajuk Buku</th>
              <th>Tarikh Sewa</th>
              <th>Status</th>
              <th>Tarikh Pulang</th>
              <th>Kurier</th>
            </tr>
          </thead>
          <tbody>
      `;

      data.forEach((item, index) => {
        html += `
          <tr>
            <td>${index + 1}</td>
            <td>${item.title}</td>
            <td>${item.rent_date}</td>
            <td>${item.status}</td>
            <td>${item.return_date ?? "-"}</td>
            <td>${item.courier_name ?? "-"}</td>
          </tr>
        `;
      });

      html += `</tbody></table>`;
      document.getElementById("status-list").innerHTML = html;
    }

    loadStatus();
  </script>

</body>
</html>
