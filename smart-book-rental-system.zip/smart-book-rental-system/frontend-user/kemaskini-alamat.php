<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Kemaskini Alamat</title>
</head>
<body>

<h2>Kemaskini Alamat Anda</h2>
<form id="address-form">
  <label for="address">Alamat:</label><br>
  <textarea id="address" name="address" rows="4" cols="50" required></textarea><br><br>
  <button type="submit">Simpan</button>
</form>

<script>
const user = JSON.parse(localStorage.getItem("user"));
if (!user || user.role !== "user") {
  alert("Sila log masuk sebagai pengguna.");
  window.location.href = "login.php";
}

document.getElementById("address-form").onsubmit = async (e) => {
  e.preventDefault();

  const address = document.getElementById("address").value;

  const res = await fetch("../api/update-address.php", {
    method: "POST",
    body: JSON.stringify({ user_id: user.id, address })
  });

  const result = await res.json();

  if (result.status === "success") {
    user.address = address;
    localStorage.setItem("user", JSON.stringify(user));
    alert("Alamat dikemaskini.");
    window.location.href = "books.php";
  } else {
    alert("Gagal kemaskini alamat.");
  }
};
</script>

</body>
</html>
