<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Senarai Buku</title>
</head>
<body>

  <div id="user-info">
    <div><strong>Pengguna Log Masuk:</strong> <span id="user-name"></span></div>
    <div>
      <button onclick="goToStatus()">Lihat Status Sewaan</button>
      <button onclick ="logout()">Log Keluar</button>
    </div>
  </div>
  
  <h2>Senarai Buku</h2>
  <div id="book-list">Memuatkan senarai buku...</div>

  <script>
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user || user.role !== "user") {
      alert("Sila log masuk sebagai pengguna.");
      window.location.href = "login.php";
    }

    document.getElementById("user-name").textContent = `${user.name} (${user.email})`;
    const userId = user.id;

    async function logout() {
      if (!confirm("Anda pasti ingin log keluar?")) {
        return; 
      }

      const user = JSON.parse(localStorage.getItem("user"));

      await fetch("../api/logout.php", {
        method: "POST",
        body: JSON.stringify({ user_id: user.id, token: user.token })
      });

      localStorage.removeItem("user");
      window.location.href = "login.php";
    }



    function goToStatus() {
      window.location.href = "status.php";
    }

    async function loadBooks() {
      const res = await fetch("../api/books.php");
      const books = await res.json();

      let html = `
        <table>
          <thead>
            <tr>
              <th>Bil</th>
              <th>Tajuk Buku</th>
              <th>Pengarang</th>
              <th>Status</th>
              <th>Tindakan</th>
            </tr>
          </thead>
          <tbody>
      `;

      books.forEach((book, index) => {
        html += `
          <tr id="row-${book.id}">
            <td>${index + 1}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td id="status-${book.id}">${book.status}</td>
            <td id="action-${book.id}">
              ${book.status === 'available'
                ? `<button onclick="rentBook(${book.id})">Sewa</button>`
                : `<em>Telah Disewa</em>`}
            </td>
          </tr>
        `;
      });

      html += `</tbody></table>`;
      document.getElementById("book-list").innerHTML = html;
    }

    async function rentBook(bookId) {
      const confirmRent = confirm("Anda pasti ingin menyewa buku ini?");
      if (!confirmRent) return; 
      
      const res = await fetch("../api/rent.php", {
        method: "POST",
        body: JSON.stringify({
          user_id: user.id,
          book_id: bookId,
          token: user.token 
        })

      });

      const result = await res.json();

      if (result.status === "success") {
        alert("✅ " + (result.message || "Buku berjaya disewa!"));
        document.getElementById(`status-${bookId}`).textContent = "rented";
        document.getElementById(`action-${bookId}`).innerHTML = `<em>Telah Disewa</em>`;
      } else {
        alert("❌ " + (result.message || "Gagal menyewa buku."));
      }
    }

    loadBooks();
  </script>

</body>
</html>
