<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Log Masuk Pengguna</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 40px;
    }
    form {
      max-width: 400px;
    }
    label, input {
      display: block;
      margin-bottom: 10px;
    }
    input[type="submit"] {
      margin-top: 20px;
    }
  </style>
</head>
<body>

  <h2>Log Masuk Pengguna</h2>

  <form id="login-form">
    <label for="email">Emel:</label>
    <input type="email" id="email" name="email" required>

    <label for="password">Kata Laluan:</label>
    <input type="password" id="password" name="password" required>

    <input type="submit" value="Log Masuk">
  </form>

  <div class="link">
    Belum ada akaun? <a href="register.php">Daftar di sini</a>
  </div>

  <script>
    document.getElementById("login-form").onsubmit = async function(e) {
      e.preventDefault();

      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;

      const res = await fetch("../api/login.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
      });

      const result = await res.json();

      if (result.status === "success") {
        const user = result.user;
        localStorage.setItem("user", JSON.stringify(user));

        // ✅ Redirect ikut role
        if (user.role === "user") {
          if (!user.address || user.address.trim() === "") {
            window.location.href = "kemaskini-alamat.php";
          } else {
            window.location.href = "books.php";
          }
        } else if (user.role === "courier") {
          window.location.href = "../frontend-courier/deliveries.php";
        } else {
          alert("Role tidak dikenali.");
        }

      } else {
        alert(result.message || "Log masuk gagal.");
      }
    }
  </script>

</body>
</html>
