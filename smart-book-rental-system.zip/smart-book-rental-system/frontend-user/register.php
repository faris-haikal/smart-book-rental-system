<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Daftar Akaun Baru</title>
 
</head>
<body>
  <div class="register-container">
    <h2>Daftar Akaun Baru</h2>
    <form id="registerForm">
      <input type="text" name="name" placeholder="Nama Penuh" required>
      <input type="email" name="email" placeholder="Alamat Email" required>
      <input type="password" name="password" placeholder="Kata Laluan" required>
      <select name="role" required>
        <option value="">-- Pilih Peranan --</option>
        <option value="user">Penyewa</option>
        <option value="courier">Kurier</option>
      </select>
      <button type="submit">Daftar</button>
    </form>
    <div class="link">
      Sudah ada akaun? <a href="login.php">Log Masuk</a>
    </div>
  </div>

  <script>
    document.getElementById("registerForm").onsubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const data = Object.fromEntries(form.entries());

    const res = await fetch("../api/register.php", {
      method: "POST",
      body: JSON.stringify(data)
    });

    const json = await res.json();

    if (json.status === "success") {
      alert("Pendaftaran berjaya!");
      window.location.href = "login.php";
    } else {
      alert(json.message || "Gagal mendaftar. Cuba lagi.");
    }
  };
  </script>
</body>
</html>
