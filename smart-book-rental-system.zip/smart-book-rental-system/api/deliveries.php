<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$courier_id = $data['courier_id'] ?? null;
$token = $data['token'] ?? null;

$stmt = $conn->prepare("SELECT id FROM users WHERE id = ? AND token = ?");
$stmt->execute([$courier_id, $token]);
if ($stmt->rowCount() === 0) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("
  SELECT 
    d.id AS delivery_id,
    b.title,
    d.delivery_status,
    u.name AS user_name,
    u.address
  FROM deliveries d
  JOIN rentals r ON d.rental_id = r.id
  JOIN books b ON r.book_id = b.id
  JOIN users u ON r.user_id = u.id
  WHERE d.courier_id = ?
");

$stmt->execute([$courier_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($tasks);
