<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $data['user_id'];

$sql = "
    SELECT b.title, r.status AS rental_status, d.delivery_status
    FROM rentals r
    JOIN books b ON r.book_id = b.id
    LEFT JOIN deliveries d ON r.id = d.rental_id
    WHERE r.user_id = ?
    ORDER BY r.rent_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->execute([$user_id]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($results);
?>
