<?php
require 'db.php';
header('Content-Type: application/json');

// Ambil data dari permintaan
$data = json_decode(file_get_contents("php://input"), true);
$user_id = $data['user_id'] ?? null;
$book_id = $data['book_id'] ?? null;
$token = $data['token'] ?? null;

// 🔒 1. Semakan asas
if (!is_numeric($user_id) || !is_numeric($book_id) || !$token) {
    echo json_encode(["status" => "error", "message" => "Permintaan tidak sah. Sila log masuk semula."]);
    exit;
}

// 🔒 2. Semak token pengguna dan role
$stmt = $conn->prepare("SELECT role FROM users WHERE id = ? AND token = ?");
$stmt->execute([$user_id, $token]);
$user = $stmt->fetch();
if (!$user || $user['role'] !== 'user') {
    echo json_encode(["status" => "error", "message" => "Akses ditolak. Log masuk tidak sah."]);
    exit;
}

// 📕 3. Semak jika buku masih available
$stmt = $conn->prepare("SELECT title, status FROM books WHERE id = ?");
$stmt->execute([$book_id]);
$book = $stmt->fetch();
if (!$book || $book['status'] !== 'available') {
    echo json_encode(["status" => "error", "message" => "Buku tidak tersedia untuk disewa"]);
    exit;
}
$book_title = $book['title'];

// 🔄 4. Semak jika user sedang menyewa buku ini
$stmt = $conn->prepare("SELECT id FROM rentals WHERE user_id = ? AND book_id = ? AND status = 'ongoing'");
$stmt->execute([$user_id, $book_id]);
if ($stmt->rowCount() > 0) {
    echo json_encode(["status" => "error", "message" => "Anda masih menyewa buku ini"]);
    exit;
}

// 📝 5. Masukkan ke jadual rentals
$stmt = $conn->prepare("INSERT INTO rentals (user_id, book_id) VALUES (?, ?)");
$stmt->execute([$user_id, $book_id]);
$rental_id = $conn->lastInsertId();

// 🔄 6. Kemas kini status buku
$conn->prepare("UPDATE books SET status = 'rented' WHERE id = ?")->execute([$book_id]);

// 🚚 7. Tugaskan kurier rawak
$courier = $conn->query("SELECT id FROM users WHERE role = 'courier' ORDER BY RAND() LIMIT 1")->fetch();
if ($courier) {
    $courier_id = $courier['id'];
    $stmt = $conn->prepare("INSERT INTO deliveries (rental_id, courier_id) VALUES (?, ?)");
    $stmt->execute([$rental_id, $courier_id]);

    // 🧾 Log ke socket/notifications.txt
    file_put_contents(
        __DIR__ . '/../socket/notifications.txt',
        "[" . date('Y-m-d H:i:s') . "] Pengguna ID $user_id menyewa buku \"$book_title\". Kurier ID $courier_id ditugaskan.\n",
        FILE_APPEND
    );
}

echo json_encode([
    "status" => "success",
    "message" => "Buku berjaya disewa. Tugasan kurier sedang diproses."
]);
