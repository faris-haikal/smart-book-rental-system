<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $data['user_id'] ?? null;
$token = $data['token'] ?? null;

$stmt = $conn->prepare("UPDATE users SET token = NULL WHERE id = ? AND token = ?");
$stmt->execute([$user_id, $token]);

echo json_encode(["status" => "success"]);
