<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');
$role = $data['role'] ?? '';

if (!$name || !$email || !$password || !$role) {
    echo json_encode(["status" => "error", "message" => "Semua maklumat diperlukan."]);
    exit;
}

// Semak jika email telah didaftarkan
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->execute([$email]);
if ($check->rowCount() > 0) {
    echo json_encode(["status" => "error", "message" => "Email telah didaftarkan."]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
$success = $stmt->execute([$name, $email, password_hash($password, PASSWORD_BCRYPT), $role]);

echo json_encode(["status" => $success ? "success" : "error"]);
