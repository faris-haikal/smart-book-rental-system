<?php
require 'db.php';

function verify_user($user_id, $expected_role = null) {
    if (!is_numeric($user_id)) return false;

    $stmt = $GLOBALS['conn']->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) return false;
    if ($expected_role && $user['role'] !== $expected_role) return false;

    return true;
}
