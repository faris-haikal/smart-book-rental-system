<?php

require 'db.php';

function checkBookStatus($book_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT title, status FROM books WHERE id = ?");
    $stmt->execute([$book_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

$server = new SoapServer(null, ['uri' => 'http://localhost/api/soap']);
$server->addFunction('checkBookStatus');
$server->handle();
