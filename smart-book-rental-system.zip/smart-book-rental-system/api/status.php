<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $data['user_id'] ?? null;

if (!is_numeric($user_id)) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("
    SELECT 
    r.id AS rental_id,
    b.title,
    r.rent_date,
    r.return_date,
    r.status,
    u2.name AS courier_name
FROM rentals r
JOIN books b ON r.book_id = b.id
LEFT JOIN deliveries d ON r.id = d.rental_id
LEFT JOIN users u2 ON d.courier_id = u2.id
WHERE r.user_id = ?
ORDER BY r.rent_date DESC
");
$stmt->execute([$user_id]);
$rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($rentals);
