<?php
require 'db.php';

$stmt = $conn->query("SELECT * FROM books");
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($books);
?>
