<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$delivery_id = $data['delivery_id'] ?? null;
$status = $data['status'] ?? '';
$token = $data['token'] ?? null;

// Semak input
if (!is_numeric($delivery_id) || !in_array($status, ['delivered', 'returned'])) {
    echo json_encode(["status" => "error", "message" => "Input tidak sah"]);
    exit;
}

// Ambil data tugasan
$stmt = $conn->prepare("
    SELECT d.*, r.book_id, r.id AS rental_id, u.id AS courier_id
    FROM deliveries d
    JOIN rentals r ON d.rental_id = r.id
    JOIN users u ON d.courier_id = u.id
    WHERE d.id = ?
");
$stmt->execute([$delivery_id]);
$delivery = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$delivery) {
    echo json_encode(["status" => "error", "message" => "Tugasan tidak dijumpai"]);
    exit;
}

// Sekiranya ada token & ingin semak keselamatan tambahan
// if ($token !== 'sometoken') {
//     echo json_encode(["status" => "error", "message" => "Token tidak sah"]);
//     exit;
// }

// Kemas kini status tugasan
$updateDelivery = $conn->prepare("UPDATE deliveries SET delivery_status = ?, delivered_at = NOW() WHERE id = ?");
$updateDelivery->execute([$status, $delivery_id]);

// Jika status ialah returned, kemas kini juga status sewaan dan buku
if ($status === 'returned') {
    $updateRental = $conn->prepare("UPDATE rentals SET status = 'returned', return_date = NOW() WHERE id = ?");
    $updateRental->execute([$delivery['rental_id']]);

    $updateBook = $conn->prepare("UPDATE books SET status = 'available' WHERE id = ?");
    $updateBook->execute([$delivery['book_id']]);
}

echo json_encode(["status" => "updated", "message" => "Status berjaya dikemas kini"]);
