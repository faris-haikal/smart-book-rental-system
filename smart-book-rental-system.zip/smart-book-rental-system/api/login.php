<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

// Ambil semua maklumat termasuk alamat
$stmt = $conn->prepare("SELECT id, name, role, email, password, address FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    // Cipta token rawak
    $token = bin2hex(random_bytes(16));

    // Jika role courier dan alamat kosong → tetapkan default alamat
    if ($user['role'] === 'courier' && empty($user['address'])) {
        $defaultAddress = "UTeM, Durian Tunggal, Melaka";
        $user['address'] = $defaultAddress;

        $update = $conn->prepare("UPDATE users SET address = ? WHERE id = ?");
        $update->execute([$defaultAddress, $user['id']]);
    }

    // Simpan token
    $conn->prepare("UPDATE users SET token = ? WHERE id = ?")->execute([$token, $user['id']]);

    // Berjaya
    echo json_encode([
        "status" => "success",
        "user" => [
            "id" => $user['id'],
            "name" => $user['name'],
            "email" => $user['email'],
            "role" => $user['role'],
            "token" => $token,
            "address" => $user['address']
        ]
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Log masuk gagal"
    ]);
}
