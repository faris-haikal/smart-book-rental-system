<?php
$data = file_get_contents(__DIR__.'/../socket/notifications.txt');
$lines = array_filter(explode("\n", $data));
echo json_encode($lines);
