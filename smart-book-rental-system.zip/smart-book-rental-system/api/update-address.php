<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $data['user_id'] ?? null;
$address = trim($data['address'] ?? '');

if (!$user_id || empty($address)) {
    echo json_encode(["status" => "error", "message" => "Alamat tidak sah"]);
    exit;
}

$stmt = $conn->prepare("UPDATE users SET address = ? WHERE id = ?");
$success = $stmt->execute([$address, $user_id]);

if ($success) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal kemaskini"]);
}
