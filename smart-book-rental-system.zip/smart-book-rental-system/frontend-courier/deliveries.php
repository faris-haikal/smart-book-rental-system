<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Tugasan Kurier</title>
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
      margin-top: 20px;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 8px;
    }
    th {
      background-color: #f2f2f2;
    }
    #courier-info {
      margin-bottom: 20px;
    }
    button {
      margin-right: 10px;
    }
  </style>
</head>
<body>

  <div id="courier-info">
    <strong>Kurier Log Masuk:</strong> <span id="courier-name"></span>
    <button onclick ="logout()">Log Keluar</button>
  </div>

  <h2>Tugasan Kurier</h2>
  <div id="tasks">Memuatkan tugasan...</div>

  <script>
    const courier = JSON.parse(localStorage.getItem("user"));

    if (!courier || courier.role !== "courier") {
      alert("Sila log masuk sebagai kurier.");
      window.location.href = "../frontend-user/login.php";
    }

    document.getElementById("courier-name").textContent = `${courier.name} (${courier.email})`;
    const courierId = courier.id;
    const token = courier.token;

    async function logout() {
      if (!confirm("Anda pasti ingin log keluar?")) {
        return; // Jika pengguna tekan Cancel, hentikan fungsi
      }

      const user = JSON.parse(localStorage.getItem("user"));

      await fetch("../api/logout.php", {
        method: "POST",
        body: JSON.stringify({ user_id: user.id, token: user.token })
      });

      localStorage.removeItem("user");
      window.location.href = "../frontend-user/login.php";
    }


    async function loadTasks() {
      const res = await fetch("../api/deliveries.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ courier_id: courierId, token: token })
      });

      const data = await res.json();

      // Tapis keluar 'returned'
      const filtered = data.filter(task => task.delivery_status !== 'returned');

      if (filtered.length === 0) {
        document.getElementById("tasks").innerHTML = "<em>Tiada tugasan buat masa ini.</em>";
        return;
      }

      let html = `
        <table>
          <thead>
            <tr>
              <th>Bil</th>
              <th>Tajuk Buku</th>
              <th>Pengguna</th>
              <th>Alamat</th>
              <th>Peta</th>
              <th>Status</th>
              <th>Tindakan</th>
            </tr>
          </thead>
          <tbody>
      `;

      filtered.forEach((task, index) => {
        html += `
          <tr>
            <td>${index + 1}</td>
            <td>${task.title}</td>
            <td>${task.user_name}</td>
            <td>${task.address ?? '-'}</td>
            <td>
              <iframe
                width="250"
                height="150"
                style="border:0"
                loading="lazy"
                allowfullscreen
                referrerpolicy="no-referrer-when-downgrade"
                src="https://www.google.com/maps?q=${encodeURIComponent(task.address)}&output=embed">
              </iframe>
            </td>
            <td>${task.delivery_status}</td>
            <td>
              <button 
                onclick="updateStatus(${task.delivery_id}, 'delivered')" 
                ${task.delivery_status !== 'pending' ? 'disabled' : ''}>
                Sahkan Penghantaran
              </button>
              <button 
                onclick="updateStatus(${task.delivery_id}, 'returned')" 
                ${task.delivery_status !== 'delivered' ? 'disabled' : ''}>
                Sahkan Pemulangan
              </button>
            </td>
          </tr>
        `;
      });

      html += `</tbody></table>`;
      document.getElementById("tasks").innerHTML = html;
    }

    function confirmUpdate(id, status) {
      const message = status === 'delivered'
        ? "Anda pasti ingin sahkan penghantaran buku ini?"
        : "Anda pasti ingin sahkan pemulangan buku ini?";

      if (confirm(message)) {
        updateStatus(id, status);
      }
    }

    async function updateStatus(id, status) {
      const res = await fetch("../api/update-status.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ delivery_id: id, status, token: token })
      });

      const result = await res.json();
      alert(result.message || (result.status === "updated" ? "Status dikemas kini!" : "Gagal kemas kini."));
      loadTasks();
    }

    loadTasks();

    setInterval(async () => {
      const res = await fetch("../api/socket-check.php");
      const lines = await res.json();
      const myTasks = lines.filter(line => line.includes(`courier_id:${courierId};`));
      if (myTasks.length > 0) {
        alert("Anda ada tugasan penghantaran baru!");
        loadTasks();
        // Optionally clear notifications
      }
    }, 10000); // semak setiap 10 saat

  </script>

</body>
</html>
